function s = mod_psk(b, constellation)
% b             : (vecteur) vecteur contenant les bits à moduler
% constellation : (vecteur) vecteur la constellation
% s             : (vecteur) vecteur de symboles modulés

s = mod_psk_(b, constellation);