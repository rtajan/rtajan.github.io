function gamma_sl = periodogramme_moy_(x, N, N_FFT, Fe)
% x : (vecteur complexe) signal
% N: (int) Taille de la fenêtre
% N_FFT: (int) nombre de points pour le calcul de la FFT
% Fe : (int) Fréquence d'échantillonnage

P = floor(length(x)/N);
X = reshape(x(1:P*N),N,[]);
periodogram_mtx = abs(fft(X,N_FFT)).^2;
gamma_sl = Fe/P/N*mean(periodogram_mtx,2).';

