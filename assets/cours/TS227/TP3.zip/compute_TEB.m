function [TEB, Pb] = compute_TEB(eb_n0_dB, constellation, g, Fse, Ns, max_bit_err)
% Arguments :
% eb_n0_dB : (vecteur réel) ensemble des valeurs de Eb/N0 à tester en dB
% constellation : (vecteur complexe) constellation des symboles
% g : (vecteur réel) Réponse impulsionnelle du filtre de mise en forme
% Fse : (int) facteur de sur-échantillonnage
% Ns : (int) Nombre de symboles à envoyer dans un paquet
% max_bit_err : (int) Nombre d'erreurs binaires à attendre avant de passer au point de Eb/N0 suivant

% Retour :
% TEB : (vecteur) Une valeur de Taux d'Erreur Binaire (TEB) par point de Eb/N0
% Pb : (vecteur) Une valeur de probabilité d'erreur par point de Eb/N0

[TEB, Pb] = compute_TEB_(eb_n0_dB, constellation, g, Fse, Ns, max_bit_err);