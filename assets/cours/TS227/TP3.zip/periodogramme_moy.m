function gamma_x = periodogramme_moy(x, N, N_FFT, Fe)
% x : (vecteur complexe) signal
% N: (int) Taille de la fenêtre
% N_FFT: (int) nombre de points pour le calcul de la FFT
% Fe : (int) Fréquence d'échantillonnage

gamma_x = periodogramme_moy_(x, N, N_FFT, Fe);