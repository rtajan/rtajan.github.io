function sl = shaping(s, Fse, g)
% s : ( vecteur complexe ) vecteur des symboles
% Fse : ( int ) Fréquence de sur - échantillonnage
% g : ( vecteur complexe ) filtre de mise en forme échantillonné

sl = shaping_(s,Fse,g);
end

