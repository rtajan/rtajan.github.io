function bh = demod_psk_(y, constellation)
% y             : (vecteur) vecteur du signal reçu
% constellation : (vecteur) vecteur de la constellation
% bh            : (vecteur) vecteur des bits démodulés

bh = demod_psk_(y, constellation);