function [TEB, Pb, s] = compute_TEB_FP(eb_n0_dB, Fp, constellation, g, Fse, Ns, max_bit_err)
% Arguments :
% eb_n0_dB : (vecteur réel) ensemble des valeurs de Eb/N0 à tester en dB
% Fp : (float) Fréquence porteuse (réduite)
% constellation : (vecteur complexe) constellation des symboles
% g : (vecteur réel) Réponse impulsionnelle du filtre de mise en forme
% Fse : (int) facteur de sur-échantillonnage
% Ns : (int) Nombre de symboles à envoyer dans un paquet
% max_bit_err : (int) Nombre d'erreurs binaires à attendre avant de passer au point de Eb/N0 suivant

% Retour :
% TEB : (vecteur) Une valeur de Taux d'Erreur Binaire (TEB) par point de Eb/N0

%% Initialisation des paramètres
M = length(constellation);
n_b = log2(M); % Nombre de bits par symboles
Nb = Ns * n_b;

Eg    = g(:)'*g(:);% Energie du filtre de mise en forme
sigA2 = constellation(:)'*constellation(:)/M;% Variance théorique des symboles
eb_n0    = 10.^(eb_n0_dB/10); % Liste des Eb/N0
sigma2   = sigA2 * Eg ./ (n_b * eb_n0); % Variance du bruit complexe en bande de base

TEB = zeros(size(eb_n0)); % Tableau des TEB (résultats)

% Déterminer probabilité d'erreurs (théorie)
if M == 2
    Pb = qfunc(sqrt(2*eb_n0));
else
    Pb = (2/n_b)*qfunc(sqrt(2*n_b*(sin(pi/M).^2)*eb_n0));
end

for i = 1:length(eb_n0)
    error_cnt = 0;
    bit_cnt = 0;
    while error_cnt < max_bit_err
        %% Émetteur
        b = randi([0, 1], 1, Nb);
        s = mod_psk(b, constellation);
        sl = shaping(s, Fse, g);
        s = real(sqrt(2) .* sl .* exp(1j*2*pi*Fp*(0:(length(sl)-1))));
        %% Canal
        n = sqrt(sigma2(i)/2) * randn(size(sl)); % Génération du bruit blanc gaussien réel
        y = s + n;
        %% Récepteur
        
        yl = sqrt(2) * y .* exp(-1j*2*pi*Fp*(0:(length(sl)-1))); % Pas catholique mais juste
        
        rn = recepteur_optimal(yl, Fse, g, Ns);
        br = demod_psk(rn, constellation);
        error_cnt = error_cnt + sum(br ~= b); % incrémenter le compteur d'erreurs
        bit_cnt   = bit_cnt   + Nb; % incrémenter le compteur de bits envoyés
    end
    TEB(i) = error_cnt/bit_cnt;
end