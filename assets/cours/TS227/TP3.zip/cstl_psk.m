function constellation = cstl_psk(M, is_gray)
% Fonction qui génère un tableau ordonné de la constellation 
% M       : (int) ordre de la modulation
% is_gray : (bool) type du mapping
%           true => "Gray", false => "Naturel"

constellation = cstl_psk_(M, is_gray);