function r_n = recepteur_optimal(y_l, Fse, g, Ns)
% Arguments :
% y_l : (vecteur complexe) signal reçu (sur-échantillonné)
% Fse : (int) facteur de sur-échantillonnage
% g : (vecteur réel) Réponse impulsionnelle du filtre de mise en forme
% Retour :
% r_n : (vecteur complexe) signal après filtrage adapté et échantillonnage à T_s

r_n = recepteur_optimal_(y_l, Fse, g, Ns);